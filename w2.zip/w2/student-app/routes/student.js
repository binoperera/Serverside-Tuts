    const express = require("express");
    const router = express.Router();

    router.get("/student", (req, res) => {
        const student = {
            name: "John Doe",
            age: 22,
            course: "Computer Science",
            university: "XYZ University"
        };
        res.render("student", { student });
    });

    module.exports = router; // Ensure you export the router
