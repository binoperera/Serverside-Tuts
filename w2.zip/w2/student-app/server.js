const express = require("express");
const path = require("path"); // Required path module for path joining
const app = express();
const studentRoutes = require("./routes/student"); // Correct path

// Set the view engine to EJS
app.set("view engine", "ejs");

// Set the path to the 'views' directory using path.join
app.set("views", path.join(__dirname, "views")); // Dynamically set the path to the views folder

// Home Route
app.get("/", (req, res) => {
    res.render("index"); // Render index.ejs
});

// Use student routes
app.use("/", studentRoutes);

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
