const express = require("express");
const router = express.Router();
const MovieModel = require("../models/MovieModel");

// Home Page - Search Form
router.get("/", (req, res) => {
    res.render("movieview");
});

// Search by Genre
router.post("/search", async (req, res) => {
    const genre = req.body.genre;
    const movies = await MovieModel.searchByGenre(genre);
    res.render("yearview", { movies, search: genre });
});

// Search by Year
router.post("/search-year", async (req, res) => {
    const year = req.body.year;
    const movies = await MovieModel.searchByYear(year);
    res.render("yearview", { movies, search: year });
});

// Search by Title
router.post("/search-title", async (req, res) => {
    const title = req.body.title;
    const movies = await MovieModel.searchByTitle(title);
    res.render("yearview", { movies, search: title });
});

// View All Movies
router.get("/allmovies", async (req, res) => {
    const movies = await MovieModel.getAllMovies();
    res.render("allview", { movies });
});

module.exports = router;
