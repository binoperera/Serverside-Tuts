const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Home page with form
app.get('/', (req, res) => {
  res.render('index');
});

// Search by genre
app.post('/search', (req, res) => {
  const genre = req.body.genre;
  db.query('SELECT * FROM movies WHERE genre = ?', [genre], (err, results) => {
    if (err) throw err;
    res.render('search', { movies: results, genre });
  });
});

// View all movies
app.get('/allmovies', (req, res) => {
  db.query('SELECT * FROM movies', (err, results) => {
    if (err) throw err;
    res.render('allmovies', { movies: results });
  });
});

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
