const express = require("express");
const router = express.Router();
const AgeModel = require("../models/agemodel");

router.get("/", (req, res) => {
    res.render("form");
});

router.post("/calculate", (req, res) => {
    const dob = req.body.dob;
    if (!dob) {
        return res.send("Please provide a valid date of birth.");
    }

    const age = AgeModel.calculateAge(dob);
    res.render("result", { age });
});

module.exports = router;
