const express = require("express");
const app = express();
const dinosaurRoutes = require("./routes/dinosaurs");

app.set("view engine", "ejs");

// Check that the root path '/' is defined
app.get("/", (req, res) => {
    res.send("Welcome to Dinosaur Periods! <a href='/dinosaurs/periods'>Go to Periods</a> ");
    
});

// Use dinosaur routes for any paths that start with '/dinosaurs'
app.use("/", dinosaurRoutes);
app.use(express.urlencoded({ extended: true }));

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
