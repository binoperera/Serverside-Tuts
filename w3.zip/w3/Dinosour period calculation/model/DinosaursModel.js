class DinosaurModel {
    static getAllPeriods() {
        return ["Triassic", "Jurassic", "Cretaceous"];
    }

    static getPeriodInfo(period) {
        const data = {
            Triassic: "Dinosaurs: Plateosaurus, Eoraptor",
            Jurassic: "Dinosaurs: Allosaurus, Brachiosaurus",
            Cretaceous: "Dinosaurs: Tyrannosaurus Rex, Velociraptor"
        };

        return data[period] || "No data available for this period.";
    }
}

module.exports = DinosaurModel;
