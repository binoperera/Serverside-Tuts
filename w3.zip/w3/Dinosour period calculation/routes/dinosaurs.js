const express = require("express");
const router = express.Router();
const DinosaurModel = require("../model/DinosaursModel");

router.get("/dinosaurs/periods", (req, res) => {
    const periods = DinosaurModel.getAllPeriods();
    res.render("periods", { periods });
});

router.get("/dinosaurs/getinfo/:period", (req, res) => {
    const period = req.params.period;
    const info = DinosaurModel.getPeriodInfo(period);
    res.render("periodinfo", { period, info });
});

module.exports = router;
